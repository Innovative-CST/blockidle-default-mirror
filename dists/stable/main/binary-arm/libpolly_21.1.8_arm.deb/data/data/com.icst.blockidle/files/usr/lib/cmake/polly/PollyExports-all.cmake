set_target_properties(LLVMPolly PROPERTIES
        IMPORTED_LOCATION_RELEASE "/data/data/com.icst.blockidle/files/usr/lib/LLVMPolly.so")
set_target_properties(PollyISL PROPERTIES
        IMPORTED_LOCATION_RELEASE "/data/data/com.icst.blockidle/files/usr/lib/libPollyISL.a")
set_target_properties(Polly PROPERTIES
        IMPORTED_LOCATION_RELEASE "/data/data/com.icst.blockidle/files/usr/lib/libPolly.a")
# Compute the installation prefix from this LLVMConfig.cmake file location.
get_filename_component(POLLY_INSTALL_PREFIX "${CMAKE_CURRENT_LIST_FILE}" REALPATH)
get_filename_component(POLLY_INSTALL_PREFIX "${POLLY_INSTALL_PREFIX}" PATH)
get_filename_component(POLLY_INSTALL_PREFIX "${POLLY_INSTALL_PREFIX}" PATH)
get_filename_component(POLLY_INSTALL_PREFIX "${POLLY_INSTALL_PREFIX}" PATH)
get_filename_component(POLLY_INSTALL_PREFIX "${POLLY_INSTALL_PREFIX}" PATH)

