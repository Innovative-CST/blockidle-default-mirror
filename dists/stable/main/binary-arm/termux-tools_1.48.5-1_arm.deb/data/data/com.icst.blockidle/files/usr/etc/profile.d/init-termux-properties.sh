if [ ! -f /data/data/com.icst.blockidle/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.icst.blockidle/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.icst.blockidle/files/home/.termux
	cp /data/data/com.icst.blockidle/files/usr/share/examples/termux/termux.properties /data/data/com.icst.blockidle/files/home/.termux/
fi
