#!/data/data/com.icst.blockidle/files/usr/bin/bash

# Setup APP_PACKAGE_MANAGER
source "/data/data/com.icst.blockidle/files/usr/bin/termux-setup-package-manager" || exit 1

terminal_width="$(stty size | cut -d" " -f2)"

if [[ "$terminal_width" =~ ^[0-9]+$ ]] && [ "$terminal_width" -gt 60 ]; then

    motd="
 \e[47m                \e[0m  \e[1m>_*\e[0m
 \e[47m                \e[0m  \e[1mWelcome to Block IDLE!\e[0m
 \e[47m  \e[0m            \e[0;37m\e[47m .\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mDiscord:\e[0m    \e[4mhttps://discord.gg/RM5qaZs4kd\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mYouTube:\e[0m    \e[4mhttps://youtube.com/@innovative-cst\e[0m
 \e[47m  \e[0m            \e[47m  \e[0m  \e[1mInstagram:\e[0m  \e[4mhttps://www.instagram.com/innovative_cst\e[0m
 \e[47m  \e[0m            \e[0;37m\e[47m .\e[0m
 \e[47m                \e[0m  \e[1mBlock IDLE version:\e[0m ${TERMUX_VERSION-Unknown}
"

    motd_indent="                   "

else

    motd="
\e[1m>_*\e[0m
\e[1mWelcome to Block IDLE!\e[0m

\e[1mDiscord:\e[0m    \e[4mhttps://discord.gg/RM5qaZs4kd\e[0m
\e[1mYouTube:\e[0m    \e[4mhttps://youtube.com/@innovative-cst\e[0m
\e[1mInstagram:\e[0m  \e[4mhttps://www.instagram.com/innovative_cst\e[0m

\e[1mBlock IDLE version:\e[0m ${TERMUX_VERSION-Unknown}
"

    motd_indent=""
fi

# Packages instructions
motd+="
${motd_indent}\e[1mWorking with packages:\e[0m
${motd_indent}\e[1mSearch:\e[0m  pkg search <query>
${motd_indent}\e[1mInstall:\e[0m pkg install <package>
${motd_indent}\e[1mUpgrade:\e[0m pkg upgrade
"

# Extra repos if APT is used
if [ "$TERMUX_APP_PACKAGE_MANAGER" = "apt" ]; then
    motd+="
${motd_indent}\e[1mSubscribing to additional repos:\e[0m
${motd_indent}\e[1mRoot:\e[0m pkg install root-repo
${motd_indent}\e[1mX11:\e[0m  pkg install x11-repo

${motd_indent}For fixing any repository issues,
${motd_indent}try 'termux-change-repo' command.
"
fi

# Report issues
motd+="
${motd_indent}Report package issues at: \e[4mhttps://github.com/Innovative-CST/termux-packages/issues\e[0m
${motd_indent}Report app issues at:     \e[4mhttps://github.com/Innovative-CST/BlockIDLE/issues\e[0m
"

# Print the motd
echo -e "$motd"